---
name: Security Issue — Private Route
about: Do not report vulnerabilities in a public Issue; use the repository Security tab.
title: ""
labels: ""
assignees: ""
---

# Stop: do not submit this public Issue

Security reports may expose creator data or a vulnerability before a fix exists.

Use the repository **Security tab → Report a vulnerability** to start a private report. If GitHub private vulnerability reporting is unavailable, follow [`SECURITY.md`](../../SECURITY.md) and contact the maintainer privately through the GitHub profile associated with the repository.

Do not paste an Email, Handle, Profile URL, Campaign detail, Token, original creator list, Run folder, or unredacted screenshot here.

